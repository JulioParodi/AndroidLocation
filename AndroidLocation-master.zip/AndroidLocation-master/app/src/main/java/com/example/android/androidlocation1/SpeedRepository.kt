package com.example.android.androidlocation1

import android.arch.lifecycle.LiveData
import android.support.annotation.WorkerThread

class SpeedRepository(private val speedDao: SpeedDao) {

    val allSpeeds: LiveData<List<Speed>> = speedDao.getSpeeds()

    @WorkerThread
    suspend fun insert(speed: Speed) {
        speedDao.insertSpeed(speed)
    }
}


