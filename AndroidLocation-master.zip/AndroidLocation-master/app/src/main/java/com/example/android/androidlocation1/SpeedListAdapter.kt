package com.example.android.androidlocation1

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class SpeedListAdapter internal constructor(
    context: Context
) : RecyclerView.Adapter<SpeedListAdapter.SpeedViewHolder>() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)
    private var speeds = emptyList<Speed>() // Cached copy of words

    inner class SpeedViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val speedItemView: TextView = itemView.findViewById(R.id.textView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SpeedViewHolder {
        val itemView = inflater.inflate(R.layout.recyclerview_item, parent, false)
        return SpeedViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: SpeedViewHolder, position: Int) {
        val current = speeds[position]
        holder.speedItemView.text = current.mySpeed
    }

    internal fun setSpeeds(speeds: List<Speed>) {
        this.speeds = speeds
        notifyDataSetChanged()
    }

    override fun getItemCount() = speeds.size
}