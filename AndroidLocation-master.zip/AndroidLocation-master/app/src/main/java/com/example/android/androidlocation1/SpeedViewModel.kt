package com.example.android.androidlocation1

import android.app.Application
import android.arch.lifecycle.AndroidViewModel
import android.arch.lifecycle.LiveData
import kotlinx.coroutines.experimental.*
import kotlinx.coroutines.experimental.android.Main
import kotlin.coroutines.experimental.CoroutineContext

class SpeedViewModel(application: Application) : AndroidViewModel(application) {

    private var parentJob = Job()
    private val coroutineContext: CoroutineContext
        get() = parentJob + Dispatchers.Main
    private val scope = CoroutineScope(coroutineContext)

    private val repository: SpeedRepository
    val allSpeeds: LiveData<List<Speed>>

    init {
        val speedDao = AppDatabase.getAppDataBase(application)?.speedDao()
        repository = SpeedRepository(speedDao!!)
        allSpeeds = repository.allSpeeds
    }

    fun insert(speed: Speed) = scope.launch(Dispatchers.IO) {
        repository.insert(speed)
    }

    override fun onCleared() {
        super.onCleared()
        parentJob.cancel()
    }
}